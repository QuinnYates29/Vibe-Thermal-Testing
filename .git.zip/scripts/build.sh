#!/usr/bin/env bash

make
