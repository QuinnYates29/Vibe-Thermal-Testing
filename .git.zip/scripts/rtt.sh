#!/usr/bin/bash

openocd -f ./rtt.cfg
