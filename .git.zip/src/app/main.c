#include "stm32g4xx_hal.h"    //HAL core & device headers
#include "dac_sine.h"         //Sine generator API

int main(void)
{
  SineGen_Init();             //builds array of table
                              // DAC1 on PA4, TIM6 for DAC sampling
                              //ADC1 on PA0 for pot.

  for (;;)
  {
    SineGen_Task();           /* reads pot and updates frequency */
    HAL_Delay(5);             // delay so the pot isn't being constantly polled, but fast enough for knob changes       
  }
}

